#include <iostream>

using namespace std;


int main(int argc, char *argv[])
{
    cout<<"hehe"<<endl;
    return 0;
}
