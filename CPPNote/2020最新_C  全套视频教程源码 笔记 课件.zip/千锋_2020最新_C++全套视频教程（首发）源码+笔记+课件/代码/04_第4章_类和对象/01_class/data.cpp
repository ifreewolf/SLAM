#include "data.h"
void Data::setNum(int n)
{
    num = n;
}
int Data::getNum(void)
{
    return num;
}
