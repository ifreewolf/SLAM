#ifndef DATA_H
#define DATA_H
class Data
{
private:
    int num;
public:
    //����num
    void setNum(int n);
    int getNum(void);
};

#endif // DATA_H
