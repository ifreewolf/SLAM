int func02(int x,int y,int z)
{
    return x+y+z;
}
