#include<stdio.h>
int my_add(int x,int y)
{
    return x+y;
}
int my_sub(int x,int y)
{
    return x-y;
}
