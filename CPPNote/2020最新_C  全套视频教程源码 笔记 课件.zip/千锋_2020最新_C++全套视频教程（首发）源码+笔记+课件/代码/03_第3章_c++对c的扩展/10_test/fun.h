#ifndef FUN_H
#define FUN_H
#if __cplusplus
extern "C"{
#endif

    extern int my_add(int x,int y);
    extern int my_sub(int x,int y);


#if __cplusplus
}
#endif

#endif // FUN_H
