#include<stdio.h>
int my_add(int x,int y)
{
    return x+y;
}
