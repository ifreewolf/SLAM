#include <iostream>
using namespace std;
#include "fun.h"
int main(int argc, char *argv[])
{

    cout<<"num = "<<my_add(100,200)<<endl;
    return 0;
}
